package com.cookie.vex;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
